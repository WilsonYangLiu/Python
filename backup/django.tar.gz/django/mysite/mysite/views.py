# -*- coding: utf-8 -*-
from django.template import RequestContext
from django.template.loader import get_template
from django.template import Context
from django.shortcuts import render_to_response
from django.http import HttpResponse,Http404
import datetime


def survey1(request,offset):
    Path = 'D:\\Downloads\\django\\templates\\'#'D:\\Google Drive\\python\\django\\'
    data = []
    #item_list = []
    try:
        files = open(Path + offset + '.txt')
        offset = int(offset)
    except ValueError:
        raise Http404()
    num = files.readline()
    number = (int)(num[3]+num[4])
    for i in range(number):
        data.append(files.readline())
    dick = {'tittle':data[0],
            'head':data[0],
            'message':data[1],
            'tip':data[2],
            }
    for i in range(number-3):
        i = i+1
        s = 'content' + (str)(i)
        dick[s] = data[i+2]
    #t = get_template('survey/survey1.html')
    #html = t.render(Context(dick))
    #return HttpResponse(html)
    return render_to_response('survey/survey1.html',dick,context_instance=RequestContext(request))

'''
    for i in range(number-3):
        item_list.append(data[i+3])
    t = get_template('survey.html')
    dick = {'tittle':data[0],
            'head':data[0],
            'message':data[1],
            'tip':data[2],
            'item_list':item_list}
    html = t.render(Context(dick))
    return HttpResponse(html)
'''
def result(request,offset1,offset2):
    Path = 'D:\\Downloads\\django\\templates\\'#'D:\\Google Drive\\python\\django\\'
    data = []
    try:
        files = open(Path + 'result1.txt')
        offset1 = int(offset1)
        offset2 = int(offset2)
    except ValueError:
        raise Http404()
    for i in range(3):
        data.append(files.readline())
    dick = {'score':offset2,
            'content1':data[0],
            'content2':data[1],
            'content3':data[2]
            }
    t = get_template('survey/result1.html')
    html = t.render(Context(dick))
    return HttpResponse(html)
    
def hello(request):
    return HttpResponse("Hello world")

'''def Current_time(request):
    now = datetime.datetime.now()
    t = get_template('current_datetime.html')
    html = t.render(Context({'current_date':now}))
    return HttpResponse(html)'''

def Current_time(request):
    now = datetime.datetime.now()
    return render_to_response('current_datetime.html',{'current_date':now})

'''def hours_ahead(request,offset):
    try:
        offset = int(offset)
    except ValueError:
        raise Http404()
    dt = datetime.datetime.now()+datetime.timedelta(hours = offset)
    t = get_template('time_plus.html')
    html = t.render(Context({'hour_offset':offset,'next_time':dt}))
    return HttpResponse(html)'''

def hours_ahead(request,offset):
    try:
        offset = int(offset)
    except ValueError:
        raise Http404()
    dt = datetime.datetime.now()+datetime.timedelta(hours = offset)
    return render_to_response('time_plus.html',{'hour_offset':offset,'next_time':dt})


    
