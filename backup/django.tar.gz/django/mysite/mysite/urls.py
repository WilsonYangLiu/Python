from django.conf.urls import patterns, include, url
import settings
from mysite.views import hello,Current_time,hours_ahead,survey1,result

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('',
                       #(r'^site_medias/(?P<path>.*)$','django.views.static.serve', {'document_root':mysite.settings.STATICFILES_DIRS, 'show_indexes': True}), 
                       #(r'^site_media/(?P.*)$', 'django.views.static.serve',{'document_root': settings.STATIC_PATH}),
                       #(r'^site_media/(?P<path>.*)$','django.views.static.serve',{'document_root':settings.STATIC_PATH}),
                       ('^hello/$',hello),
                       ('^time/$',Current_time),
                       (r'^time/plus/(\d{1,3})/$',hours_ahead),
                       (r'^survey/(\d{1,3})/$',survey1),
                       (r'^survey/(\d{1,3})/(\d{1,3})/$',result),
                       (r'^site_media/(?P<path>.*)$','django.views.static.serve',{'document_root': settings.STATIC_PATH}),
    # Examples:
    # url(r'^$', 'mysite.views.home', name='home'),
    # url(r'^mysite/', include('mysite.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    # url(r'^admin/', include(admin.site.urls)),
)
